# Product Context

## Why this exists
Traditional clustering can hide nuanced relationships across different customer attributes. A graph representation can capture multiple relationship types and yield more interpretable “communities”.

## Target user
Students and academics demonstrating community detection on customer segmentation; small business analysts exploring customer groups.

## User experience goals
- Minimal steps: upload dataset → click “Analyze” → see segments + plot.
- Clear output: community id, size, and simple segment labels (e.g., high-value / average / budget) derived from attribute summaries.
- Fast: runs locally in seconds for typical dataset sizes (hundreds–few thousands).

