# Customer Community Detection (Multi-Attributed Graph)

Upload a customer dataset (e.g., Mall Customers) and segment customers into communities using a multi-attributed similarity graph and community detection.

## Setup (Windows / PowerShell)

```bash
cd C:\Users\Pranju\customer-community-graph-app
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Dataset format

The app tries to auto-detect these columns (case-insensitive):
- Age
- Annual Income (k$) / Income
- Spending Score (1-100) / SpendingScore / Spending Score

If you have different column names, rename them to match one of the above.

