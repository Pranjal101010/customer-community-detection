# Project Brief: Customer Community Detection (Multi-Attributed Graph)

## Goal
Build a simple web app that segments customers into meaningful communities by modeling them as nodes in a multi-attributed similarity graph (age, income, spending score) and running community detection.

## Core features
- Upload a CSV dataset (or use a bundled sample similar to “Mall Customers”).
- Construct a graph where each customer is a node.
- Create multiple similarity relationships (age, income, spending) and combine them into weighted edges.
- Run a community detection algorithm (Label Propagation; Louvain when available).
- Present communities in a user-friendly web UI with a basic visualization and a downloadable labeled CSV.

## Non-goals (for initial version)
- Authentication, multi-user accounts
- Real-time streaming data
- Complex interactive dashboards (keep visuals simple)

