# System Patterns

## Architecture
- Flask server renders HTML templates.
- Data pipeline: CSV → pandas DataFrame → normalized features → similarity graph (NetworkX) → community detection → summaries + plot (Matplotlib) → UI.

## Graph modeling pattern
- Each customer is a node with attributes.
- Multiple relationship channels (age/income/spending) contribute to a single edge weight:
  - compute per-attribute similarity
  - combine via weighted sum
  - create edges for top-k neighbors (keeps graph sparse and fast)

## Community detection
- Default: NetworkX Label Propagation (no extra dependency).
- Optional: Louvain when `python-louvain` is installed.

