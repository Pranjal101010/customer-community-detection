# Active Context

## Current focus
Implement the initial working web app: upload/use sample dataset, build multi-attributed similarity graph, detect communities, and show results with a saved plot.

## Decisions
- Keep UI simple (single page form + results page).
- Keep graph sparse via top-k neighbors per node.
- Use Label Propagation by default; Louvain optional.

## Next steps
- Add interactive plot (future).
- Add per-community labeling heuristics (high-value/average/budget) based on spending and income quantiles.

