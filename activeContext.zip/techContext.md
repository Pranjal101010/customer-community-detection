# Tech Context

## Stack
- Backend: Python + Flask
- Data: pandas, numpy
- Graph: networkx
- Visualization: matplotlib

## Environment
- Runs locally on Windows 10 via `python -m venv .venv` and `pip install -r requirements.txt`

