# Progress

## Status
- Memory Bank initialized for this project.

## Done
- Created `memory-bank/` core docs.

## Next
- Scaffold Flask app, templates, and sample data.
- Implement graph + community detection pipeline.
- Add basic results visualization and download.

